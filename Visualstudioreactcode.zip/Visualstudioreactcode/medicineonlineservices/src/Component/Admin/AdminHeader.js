import React from 'react'

export default function AdminHeader(){
    return (
        <div>
            AdminHeader
        </div>
    )
}
// const Header = () => {
//   return (
//     <div>
//       Header
//     </div>
//   )
// }

// export default Header

import React from 'react'

export default function AdminOrder(){
    return (
        <div>
            AdminOrder
        </div>
    )
}
// const Deskboard = () => {
//   return (
//     <div>
//       Deskboard
//     </div>
//   )
// }

// export default Deskboard

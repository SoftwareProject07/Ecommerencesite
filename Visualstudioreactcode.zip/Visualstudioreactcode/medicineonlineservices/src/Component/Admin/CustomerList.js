import React from 'react'

export default function CustomerList(){
    return (
        <div>
            CustomerList
        </div>
    )
}
// const Deskboard = () => {
//   return (
//     <div>
//       Deskboard
//     </div>
//   )
// }

// export default Deskboard

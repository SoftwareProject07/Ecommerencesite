import React from 'react'

export default function MedicineDisplay(){
    return (
        <div>
            MedicineDisplay
        </div>
    )
}
// const Deskboard = () => {
//   return (
//     <div>
//       Deskboard
//     </div>
//   )
// }

// export default Deskboard

import React from 'react'

export default function Profile(){
    return (
        <div>
            Profile
        </div>
    )
}
// const Deskboard = () => {
//   return (
//     <div>
//       Deskboard
//     </div>
//   )
// }

// export default Deskboard
